#-------------------------------------------------#
# Title: Functions and Classes
# Developer: J. Chen
# Date: November 6, 2016
# Description: See Objective and Criteria below
# ChangeLog: NA
#-------------------------------------------------#
# Objective and Criteria:

# 1 - Make a function for the code that loads the
# each rows of data you have in the ToDo.txt text file
# into a python Dictionary and adds it to a Python List.

# 2 - Make a function for the code that displays
# the contents of the List to the user.

# 3 - Make a function for the code that allows
# the user to Add or Remove tasks from the list, plus
# save the tasks in the List tasks-priorities using
# numbered choices.

# 4 - Make a function for the code that saves the
# data from the table into the Todo.txt file
# when the program exits.

# 5 - Make a Class to hold the functions.
#-------------------------------------------------#
# Pseudo Code:

# Step 1 - Create a function that extracts the data
# from a file called ToDo.txt; name the function loadData()

# Step 2 - Create a function that displays the list of tasks
# and the associated priority; name the function displayList()

# Step 3 - Create a function that allows a user to either display
# the task list, add a new task, remove a task, or exits and saves
# the changes using a 'while' function with if-elif-else features;
# name the function editList()

# Step 4 - Create a function that writes the changes that have been
# made using the Program to the ToDo.txt; name the function saveList()

# Step 5 - Create a class called manageList() that holds the following
# functions: loadData(), displayList(), editList(), and saveList()

# Step 6 - Call the following:
    # manageList.loadData()
    # manageList.displayList()
    # manageList.editList()
    # manageList.saveList()
#-------------------------------------------------#

lstTable = []

class manageList():# create class to manage To Do list

    @staticmethod
    def loadData():
        '''Loads the data from the 'ToDo' list into the program'''
        objFile = open("C:\_PythonClass\Assignment06\ToDo.txt", "r")
        for line in objFile:
            x, y = line.split(",")
            dicRow = {"Task":x.strip(), "Priority":y.strip()}
            lstTable.append(dicRow)
        objFile.close ()

    @staticmethod
    def displayList():
        '''Displays all of the tasks currently on the list'''
        print("\nYour 'To Do' list includes the following task(s):\n")
        for i in lstTable:
            print("\tTask: " + i["Task"] + ", Priority: " + i["Priority"])
        print("---------------------------------------------------")

    @staticmethod
    def editList():
        '''Displays the valid options a user has for this program'''
        while(True):
            print("\nWhat would you like to do?")
            print("\t1.) Display the 'To Do' list")
            print("\t2.) Add a new task")
            print("\t3.) Remove an existing task")
            print("\t4.) Save changes and exit the program")

            strOptions = input("Which option would you like to choose: ")

            if(strOptions == "1"): #display to do list
                print("\nYour 'To Do' list includes the following task(s):")
                for i in lstTable:
                    print("\tTask: " + i["Task"] + ", Priority: " + i["Priority"])

            elif(strOptions == "2"): #add a new task
                strTask = input("\nEnter a new task: ")
                strPriority = input("Enter the priority of the new task: ")
                dicAdd = {"Task":strTask.title(), "Priority":strPriority.title()}  # add new task
                lstTable.append(dicAdd)  # update the table
                print("\n\t'" + strTask.title() + "' has been added to your 'To Do' list:")

            elif(strOptions == "3"): #remove an existing task
                print("\nYour 'To Do' list includes the following:")
                for i in lstTable:
                    print("\t" + str(lstTable.index(i)) + " - Task: " + i["Task"] + ", Priority: " + i["Priority"])
                intRemove = int(input("\nWhich Task do you want to remove? Enter the #: "))
                if (intRemove >= 0 and intRemove <len(lstTable)):
                    lstTable.pop(intRemove)
                    print("\n\tTask has been removed.")
                else:
                    print("\n\tERROR: An invalid Task # was entered.")

            elif(strOptions == "4"): # save edits to the list
                break

            else: #Invalid choice
                print("\n\tERROR: Please choose a valid option from the menu.")

    @staticmethod
    def saveList():
        objFile = open("C:\_PythonClass\Assignment06\ToDo.txt", "w")
        for i in lstTable:
            objFile.write(i["Task"] + ", " + i["Priority"] + "\n")
        print("\nYour 'To Do' list has been updated. Good Bye.")

manageList.loadData()
manageList.displayList()
manageList.editList()
manageList.saveList()
